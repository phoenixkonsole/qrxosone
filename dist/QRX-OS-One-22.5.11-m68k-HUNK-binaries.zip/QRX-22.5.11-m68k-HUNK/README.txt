Prebuilt m68k HUNK binaries of QRX OS One 22.5.11 (Deadwood m68k-aros-gcc 10.5.0, AROS master 5b5fd4c SDK, elf2hunk).
Copy C/* to QRX:C, Tests/* to QRX:Tests/Amiga, TestAmigaRun to QRX:S. QRXDesktop is not included (needs the real qrx_wallpaper.h from the v0.20 payload).
