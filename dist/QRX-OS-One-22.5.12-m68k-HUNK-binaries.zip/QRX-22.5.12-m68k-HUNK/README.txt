Prebuilt m68k HUNK binaries of QRX OS One 22.5.12 (Deadwood m68k-aros-gcc, AROS master 5b5fd4c SDK, elf2hunk).
C/: qrx-i386 (Linux i386 programs), qrx-win32 (Win32 programs incl. DirectX 3 HLE), 22.5.11 launcher tools.
Windows/: QRXClock and dxtest (own MinGW programs, sources in the source ZIP).
Needs a 68040/68060 with FPU.  Usage: qrx-win32 sol.exe  /  qrx-i386 busybox ls
ReactOS programs (calc, winmine, sol, spider, cards.dll) come from the ReactOS 0.4.15 live image (upstream/reactos), not from this ZIP.
