#----------------------------------------------------------------
# Generated CMake target import file for configuration "DEBUG".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cunit" for configuration "DEBUG"
set_property(TARGET cunit APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBUG)
set_target_properties(cunit PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_DEBUG "C"
  IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/lib/libcunit.a"
  )

list(APPEND _cmake_import_check_targets cunit )
list(APPEND _cmake_import_check_files_for_cunit "${_IMPORT_PREFIX}/lib/libcunit.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
