#ifndef PROTO_WORKBENCH_H
#define PROTO_WORKBENCH_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/workbench/workbench.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/workbench_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__WORKBENCH_NOLIBBASE__)
  #if !defined(WorkbenchBase)
   extern struct Library *WorkbenchBase;
  #endif
 #endif
 #ifndef __WORKBENCH_LIBBASE
  #define __WORKBENCH_LIBBASE (WorkbenchBase)
 #endif
#ifndef __aros_getbase_WorkbenchBase
extern struct Library *__aros_getbase_WorkbenchBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(WORKBENCH_NOLIBINLINE)
# include <inline/workbench.h>
#elif !defined(NOLIBDEFINES) && !defined(WORKBENCH_NOLIBDEFINES)
# include <defines/workbench.h>
#endif

#endif /* PROTO_WORKBENCH_H */
