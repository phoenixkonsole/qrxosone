#ifndef PROTO_POPUPMENU_H
#define PROTO_POPUPMENU_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/popupmenu/popupmenu.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/popupmenu_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__POPUPMENU_NOLIBBASE__)
  #if !defined(PopupMenuBase)
   #ifdef __POPUPMENU_STDLIBBASE__
    extern struct Library *PopupMenuBase;
   #else
    extern struct PopupMenuBase *PopupMenuBase;
   #endif
  #endif
 #endif
 #ifndef __POPUPMENU_LIBBASE
  #define __POPUPMENU_LIBBASE (PopupMenuBase)
 #endif
#ifndef __aros_getbase_PopupMenuBase
extern struct PopupMenuBase *__aros_getbase_PopupMenuBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(POPUPMENU_NOLIBINLINE)
# include <inline/popupmenu.h>
#elif !defined(NOLIBDEFINES) && !defined(POPUPMENU_NOLIBDEFINES)
# include <defines/popupmenu.h>
#endif

#endif /* PROTO_POPUPMENU_H */
