#ifndef PROTO_Z1_H
#define PROTO_Z1_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/z/z1.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/z1_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__Z1_NOLIBBASE__)
  #if !defined(Z1Base)
   extern struct Library *Z1Base;
  #endif
 #endif
 #ifndef __Z1_LIBBASE
  #define __Z1_LIBBASE (Z1Base)
 #endif
#ifndef __aros_getbase_Z1Base
extern struct Library *__aros_getbase_Z1Base(void);
#endif

#if !defined(NOLIBINLINE) && !defined(Z1_NOLIBINLINE)
# include <inline/z1.h>
#elif !defined(NOLIBDEFINES) && !defined(Z1_NOLIBDEFINES)
# include <defines/z1.h>
#endif

#endif /* PROTO_Z1_H */
