#ifndef PROTO_DISKIMAGE_H
#define PROTO_DISKIMAGE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/devs/diskimage/device/diskimage.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/diskimage_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DISKIMAGE_NOLIBBASE__)
  #if !defined(DiskImageBase)
   #ifdef __DISKIMAGE_STDLIBBASE__
    extern struct Library *DiskImageBase;
   #else
    extern struct Device *DiskImageBase;
   #endif
  #endif
 #endif
 #ifndef __DISKIMAGE_LIBBASE
  #define __DISKIMAGE_LIBBASE (DiskImageBase)
 #endif
#ifndef __aros_getbase_DiskImageBase
extern struct Device *__aros_getbase_DiskImageBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DISKIMAGE_NOLIBINLINE)
# include <inline/diskimage.h>
#elif !defined(NOLIBDEFINES) && !defined(DISKIMAGE_NOLIBDEFINES)
# include <defines/diskimage.h>
#endif

#endif /* PROTO_DISKIMAGE_H */
