#ifndef PROTO_MATHIEEESINGBAS_H
#define PROTO_MATHIEEESINGBAS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/mathieeesingbas/mathieeesingbas.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/mathieeesingbas_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MATHIEEESINGBAS_NOLIBBASE__)
  #if !defined(MathIeeeSingBasBase)
   extern struct Library *MathIeeeSingBasBase;
  #endif
 #endif
 #ifndef __MATHIEEESINGBAS_LIBBASE
  #define __MATHIEEESINGBAS_LIBBASE (MathIeeeSingBasBase)
 #endif
#ifndef __aros_getbase_MathIeeeSingBasBase
extern struct Library *__aros_getbase_MathIeeeSingBasBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MATHIEEESINGBAS_NOLIBINLINE)
# include <inline/mathieeesingbas.h>
#elif !defined(NOLIBDEFINES) && !defined(MATHIEEESINGBAS_NOLIBDEFINES)
# include <defines/mathieeesingbas.h>
#endif

#endif /* PROTO_MATHIEEESINGBAS_H */
