#ifndef PROTO_KMS_H
#define PROTO_KMS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/kms/kms.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/kms_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__KMS_NOLIBBASE__)
  #if !defined(KMSBase)
   #ifdef __KMS_STDLIBBASE__
    extern struct Library *KMSBase;
   #else
    extern struct KMSLibrary *KMSBase;
   #endif
  #endif
 #endif
 #ifndef __KMS_LIBBASE
  #define __KMS_LIBBASE (KMSBase)
 #endif
#ifndef __aros_getbase_KMSBase
extern struct KMSLibrary *__aros_getbase_KMSBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(KMS_NOLIBINLINE)
# include <inline/kms.h>
#elif !defined(NOLIBDEFINES) && !defined(KMS_NOLIBDEFINES)
# include <defines/kms.h>
#endif

#endif /* PROTO_KMS_H */
