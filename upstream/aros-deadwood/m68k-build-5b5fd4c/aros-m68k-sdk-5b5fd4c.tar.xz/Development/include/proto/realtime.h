#ifndef PROTO_REALTIME_H
#define PROTO_REALTIME_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/realtime/realtime.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/realtime_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__REALTIME_NOLIBBASE__)
  #if !defined(RealTimeBase)
   extern struct Library *RealTimeBase;
  #endif
 #endif
 #ifndef __REALTIME_LIBBASE
  #define __REALTIME_LIBBASE (RealTimeBase)
 #endif
#ifndef __aros_getbase_RealTimeBase
extern struct Library *__aros_getbase_RealTimeBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(REALTIME_NOLIBINLINE)
# include <inline/realtime.h>
#elif !defined(NOLIBDEFINES) && !defined(REALTIME_NOLIBDEFINES)
# include <defines/realtime.h>
#endif

#endif /* PROTO_REALTIME_H */
