#ifndef PROTO_DISKFONT_H
#define PROTO_DISKFONT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/diskfont/diskfont.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/diskfont_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DISKFONT_NOLIBBASE__)
  #if !defined(DiskfontBase)
   extern struct Library *DiskfontBase;
  #endif
 #endif
 #ifndef __DISKFONT_LIBBASE
  #define __DISKFONT_LIBBASE (DiskfontBase)
 #endif
#ifndef __aros_getbase_DiskfontBase
extern struct Library *__aros_getbase_DiskfontBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DISKFONT_NOLIBINLINE)
# include <inline/diskfont.h>
#elif !defined(NOLIBDEFINES) && !defined(DISKFONT_NOLIBDEFINES)
# include <defines/diskfont.h>
#endif

#endif /* PROTO_DISKFONT_H */
