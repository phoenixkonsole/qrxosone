#ifndef PROTO_MATHIEEEDOUBTRANS_H
#define PROTO_MATHIEEEDOUBTRANS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/mathieeedoubtrans/mathieeedoubtrans.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/mathieeedoubtrans_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MATHIEEEDOUBTRANS_NOLIBBASE__)
  #if !defined(MathIeeeDoubTransBase)
   extern struct Library *MathIeeeDoubTransBase;
  #endif
 #endif
 #ifndef __MATHIEEEDOUBTRANS_LIBBASE
  #define __MATHIEEEDOUBTRANS_LIBBASE (MathIeeeDoubTransBase)
 #endif
#ifndef __aros_getbase_MathIeeeDoubTransBase
extern struct Library *__aros_getbase_MathIeeeDoubTransBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MATHIEEEDOUBTRANS_NOLIBINLINE)
# include <inline/mathieeedoubtrans.h>
#elif !defined(NOLIBDEFINES) && !defined(MATHIEEEDOUBTRANS_NOLIBDEFINES)
# include <defines/mathieeedoubtrans.h>
#endif

#endif /* PROTO_MATHIEEEDOUBTRANS_H */
