#ifndef PROTO_TIMER_H
#define PROTO_TIMER_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/timer/timer.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/timer_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__TIMER_NOLIBBASE__)
  #if !defined(TimerBase)
   #ifdef __TIMER_STDLIBBASE__
    extern struct Library *TimerBase;
   #else
    extern struct Device *TimerBase;
   #endif
  #endif
 #endif
 #ifndef __TIMER_LIBBASE
  #define __TIMER_LIBBASE (TimerBase)
 #endif
#ifndef __aros_getbase_TimerBase
extern struct Device *__aros_getbase_TimerBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(TIMER_NOLIBINLINE)
# include <inline/timer.h>
#elif !defined(NOLIBDEFINES) && !defined(TIMER_NOLIBDEFINES)
# include <defines/timer.h>
#endif

#endif /* PROTO_TIMER_H */
