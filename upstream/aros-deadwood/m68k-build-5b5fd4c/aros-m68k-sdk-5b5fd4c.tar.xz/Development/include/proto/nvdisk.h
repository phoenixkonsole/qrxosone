#ifndef PROTO_NVDISK_H
#define PROTO_NVDISK_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/nonvolatile/nvdisk/nvdisk.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/nvdisk_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__NVDISK_NOLIBBASE__)
  #if !defined(nvdBase)
   extern struct Library *nvdBase;
  #endif
 #endif
 #ifndef __NVDISK_LIBBASE
  #define __NVDISK_LIBBASE (nvdBase)
 #endif
#ifndef __aros_getbase_nvdBase
extern struct Library *__aros_getbase_nvdBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(NVDISK_NOLIBINLINE)
# include <inline/nvdisk.h>
#elif !defined(NOLIBDEFINES) && !defined(NVDISK_NOLIBDEFINES)
# include <defines/nvdisk.h>
#endif

#endif /* PROTO_NVDISK_H */
