#ifndef PROTO_BOOTLOADER_H
#define PROTO_BOOTLOADER_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/bootloader/bootloader.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/bootloader_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__BOOTLOADER_NOLIBBASE__)
  #if !defined(BootLoaderBase)
   #ifdef __BOOTLOADER_STDLIBBASE__
    extern struct Library *BootLoaderBase;
   #else
    extern APTR BootLoaderBase;
   #endif
  #endif
 #endif
 #ifndef __BOOTLOADER_LIBBASE
  #define __BOOTLOADER_LIBBASE (BootLoaderBase)
 #endif
#ifndef __aros_getbase_BootLoaderBase
extern APTR __aros_getbase_BootLoaderBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(BOOTLOADER_NOLIBINLINE)
# include <inline/bootloader.h>
#elif !defined(NOLIBDEFINES) && !defined(BOOTLOADER_NOLIBDEFINES)
# include <defines/bootloader.h>
#endif

#endif /* PROTO_BOOTLOADER_H */
