#ifndef PROTO_MATHIEEEDOUBBAS_H
#define PROTO_MATHIEEEDOUBBAS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/mathieeedoubbas/mathieeedoubbas.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/mathieeedoubbas_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MATHIEEEDOUBBAS_NOLIBBASE__)
  #if !defined(MathIeeeDoubBasBase)
   extern struct Library *MathIeeeDoubBasBase;
  #endif
 #endif
 #ifndef __MATHIEEEDOUBBAS_LIBBASE
  #define __MATHIEEEDOUBBAS_LIBBASE (MathIeeeDoubBasBase)
 #endif
#ifndef __aros_getbase_MathIeeeDoubBasBase
extern struct Library *__aros_getbase_MathIeeeDoubBasBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MATHIEEEDOUBBAS_NOLIBINLINE)
# include <inline/mathieeedoubbas.h>
#elif !defined(NOLIBDEFINES) && !defined(MATHIEEEDOUBBAS_NOLIBDEFINES)
# include <defines/mathieeedoubbas.h>
#endif

#endif /* PROTO_MATHIEEEDOUBBAS_H */
