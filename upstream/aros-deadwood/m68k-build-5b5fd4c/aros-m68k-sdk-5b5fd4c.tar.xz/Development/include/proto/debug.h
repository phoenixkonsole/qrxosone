#ifndef PROTO_DEBUG_H
#define PROTO_DEBUG_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/debug/debug.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/debug_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DEBUG_NOLIBBASE__)
  #if !defined(DebugBase)
   extern struct Library *DebugBase;
  #endif
 #endif
 #ifndef __DEBUG_LIBBASE
  #define __DEBUG_LIBBASE (DebugBase)
 #endif
#ifndef __aros_getbase_DebugBase
extern struct Library *__aros_getbase_DebugBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DEBUG_NOLIBINLINE)
# include <inline/debug.h>
#elif !defined(NOLIBDEFINES) && !defined(DEBUG_NOLIBDEFINES)
# include <defines/debug.h>
#endif

#endif /* PROTO_DEBUG_H */
