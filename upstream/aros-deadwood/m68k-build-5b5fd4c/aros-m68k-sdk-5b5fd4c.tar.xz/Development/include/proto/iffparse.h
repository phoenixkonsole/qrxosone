#ifndef PROTO_IFFPARSE_H
#define PROTO_IFFPARSE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/iffparse/iffparse.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/iffparse_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__IFFPARSE_NOLIBBASE__)
  #if !defined(IFFParseBase)
   extern struct Library *IFFParseBase;
  #endif
 #endif
 #ifndef __IFFPARSE_LIBBASE
  #define __IFFPARSE_LIBBASE (IFFParseBase)
 #endif
#ifndef __aros_getbase_IFFParseBase
extern struct Library *__aros_getbase_IFFParseBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(IFFPARSE_NOLIBINLINE)
# include <inline/iffparse.h>
#elif !defined(NOLIBDEFINES) && !defined(IFFPARSE_NOLIBDEFINES)
# include <defines/iffparse.h>
#endif

#endif /* PROTO_IFFPARSE_H */
