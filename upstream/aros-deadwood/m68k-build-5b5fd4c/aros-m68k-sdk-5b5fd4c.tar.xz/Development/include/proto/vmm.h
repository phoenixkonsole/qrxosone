#ifndef PROTO_VMM_H
#define PROTO_VMM_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/system/VMM/vmm.lib/vmm.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/vmm_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__VMM_NOLIBBASE__)
  #if !defined(VMMBase)
   extern struct Library *VMMBase;
  #endif
 #endif
 #ifndef __VMM_LIBBASE
  #define __VMM_LIBBASE (VMMBase)
 #endif
#ifndef __aros_getbase_VMMBase
extern struct Library *__aros_getbase_VMMBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(VMM_NOLIBINLINE)
# include <inline/vmm.h>
#elif !defined(NOLIBDEFINES) && !defined(VMM_NOLIBDEFINES)
# include <defines/vmm.h>
#endif

#endif /* PROTO_VMM_H */
