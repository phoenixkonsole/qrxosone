#ifndef PROTO_PCCARD_H
#define PROTO_PCCARD_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/pccard/pccard.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/pccard_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__PCCARD_NOLIBBASE__)
  #if !defined(PCCardBase)
   extern struct Library *PCCardBase;
  #endif
 #endif
 #ifndef __PCCARD_LIBBASE
  #define __PCCARD_LIBBASE (PCCardBase)
 #endif
#ifndef __aros_getbase_PCCardBase
extern struct Library *__aros_getbase_PCCardBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PCCARD_NOLIBINLINE)
# include <inline/pccard.h>
#elif !defined(NOLIBDEFINES) && !defined(PCCARD_NOLIBDEFINES)
# include <defines/pccard.h>
#endif

#endif /* PROTO_PCCARD_H */
