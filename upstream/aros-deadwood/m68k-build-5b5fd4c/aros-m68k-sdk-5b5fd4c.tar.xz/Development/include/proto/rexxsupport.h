#ifndef PROTO_REXXSUPPORT_H
#define PROTO_REXXSUPPORT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/rexxsupport/rexxsupport.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/rexxsupport_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__REXXSUPPORT_NOLIBBASE__)
  #if !defined(RexxSupportBase)
   extern struct Library *RexxSupportBase;
  #endif
 #endif
 #ifndef __REXXSUPPORT_LIBBASE
  #define __REXXSUPPORT_LIBBASE (RexxSupportBase)
 #endif
#ifndef __aros_getbase_RexxSupportBase
extern struct Library *__aros_getbase_RexxSupportBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(REXXSUPPORT_NOLIBINLINE)
# include <inline/rexxsupport.h>
#elif !defined(NOLIBDEFINES) && !defined(REXXSUPPORT_NOLIBDEFINES)
# include <defines/rexxsupport.h>
#endif

#endif /* PROTO_REXXSUPPORT_H */
