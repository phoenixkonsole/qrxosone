#ifndef PROTO_M_H
#define PROTO_M_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/compiler/crt/m.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/m_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__M_NOLIBBASE__)
  #if !defined(MBase)
   extern struct Library *MBase;
  #endif
 #endif
 #ifndef __M_LIBBASE
  #define __M_LIBBASE (MBase)
 #endif
#ifndef __aros_getbase_MBase
extern struct Library *__aros_getbase_MBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(M_NOLIBINLINE)
# include <inline/m.h>
#elif !defined(NOLIBDEFINES) && !defined(M_NOLIBDEFINES)
# include <defines/m.h>
#endif

#endif /* PROTO_M_H */
