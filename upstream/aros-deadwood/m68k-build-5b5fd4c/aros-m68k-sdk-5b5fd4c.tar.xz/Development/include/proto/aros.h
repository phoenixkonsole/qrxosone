#ifndef PROTO_AROS_H
#define PROTO_AROS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/aros/aros.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/aros_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__AROS_NOLIBBASE__)
  #if !defined(ArosBase)
   extern struct Library *ArosBase;
  #endif
 #endif
 #ifndef __AROS_LIBBASE
  #define __AROS_LIBBASE (ArosBase)
 #endif
#ifndef __aros_getbase_ArosBase
extern struct Library *__aros_getbase_ArosBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(AROS_NOLIBINLINE)
# include <inline/aros.h>
#elif !defined(NOLIBDEFINES) && !defined(AROS_NOLIBDEFINES)
# include <defines/aros.h>
#endif

#endif /* PROTO_AROS_H */
