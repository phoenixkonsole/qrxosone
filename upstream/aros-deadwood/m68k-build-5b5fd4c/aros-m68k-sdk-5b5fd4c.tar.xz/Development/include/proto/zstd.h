#ifndef PROTO_ZSTD_H
#define PROTO_ZSTD_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/zstd/zstd.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/zstd_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__ZSTD_NOLIBBASE__)
  #if !defined(ZSTDBase)
   extern struct Library *ZSTDBase;
  #endif
 #endif
 #ifndef __ZSTD_LIBBASE
  #define __ZSTD_LIBBASE (ZSTDBase)
 #endif
#ifndef __aros_getbase_ZSTDBase
extern struct Library *__aros_getbase_ZSTDBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(ZSTD_NOLIBINLINE)
# include <inline/zstd.h>
#elif !defined(NOLIBDEFINES) && !defined(ZSTD_NOLIBDEFINES)
# include <defines/zstd.h>
#endif

#endif /* PROTO_ZSTD_H */
