#ifndef PROTO_MUISCREEN_H
#define PROTO_MUISCREEN_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/muiscreen/muiscreen.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/muiscreen_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MUISCREEN_NOLIBBASE__)
  #if !defined(MUIScreenBase)
   extern struct Library *MUIScreenBase;
  #endif
 #endif
 #ifndef __MUISCREEN_LIBBASE
  #define __MUISCREEN_LIBBASE (MUIScreenBase)
 #endif
#ifndef __aros_getbase_MUIScreenBase
extern struct Library *__aros_getbase_MUIScreenBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MUISCREEN_NOLIBINLINE)
# include <inline/muiscreen.h>
#elif !defined(NOLIBDEFINES) && !defined(MUISCREEN_NOLIBDEFINES)
# include <defines/muiscreen.h>
#endif

#endif /* PROTO_MUISCREEN_H */
