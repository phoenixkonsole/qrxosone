#ifndef PROTO_CAMD_H
#define PROTO_CAMD_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/camd/camd.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/camd_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__CAMD_NOLIBBASE__)
  #if !defined(CamdBase)
   extern struct Library *CamdBase;
  #endif
 #endif
 #ifndef __CAMD_LIBBASE
  #define __CAMD_LIBBASE (CamdBase)
 #endif
#ifndef __aros_getbase_CamdBase
extern struct Library *__aros_getbase_CamdBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(CAMD_NOLIBINLINE)
# include <inline/camd.h>
#elif !defined(NOLIBDEFINES) && !defined(CAMD_NOLIBDEFINES)
# include <defines/camd.h>
#endif

#endif /* PROTO_CAMD_H */
