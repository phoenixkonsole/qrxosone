#ifndef PROTO_COMMODITIES_H
#define PROTO_COMMODITIES_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/commodities/commodities.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/commodities_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__COMMODITIES_NOLIBBASE__)
  #if !defined(CxBase)
   extern struct Library *CxBase;
  #endif
 #endif
 #ifndef __COMMODITIES_LIBBASE
  #define __COMMODITIES_LIBBASE (CxBase)
 #endif
#ifndef __aros_getbase_CxBase
extern struct Library *__aros_getbase_CxBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(COMMODITIES_NOLIBINLINE)
# include <inline/commodities.h>
#elif !defined(NOLIBDEFINES) && !defined(COMMODITIES_NOLIBDEFINES)
# include <defines/commodities.h>
#endif

#endif /* PROTO_COMMODITIES_H */
