#ifndef PROTO_AMIGAGUIDE_H
#define PROTO_AMIGAGUIDE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/amigaguide/amigaguide.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/amigaguide_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__AMIGAGUIDE_NOLIBBASE__)
  #if !defined(AmigaGuideBase)
   extern struct Library *AmigaGuideBase;
  #endif
 #endif
 #ifndef __AMIGAGUIDE_LIBBASE
  #define __AMIGAGUIDE_LIBBASE (AmigaGuideBase)
 #endif
#ifndef __aros_getbase_AmigaGuideBase
extern struct Library *__aros_getbase_AmigaGuideBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(AMIGAGUIDE_NOLIBINLINE)
# include <inline/amigaguide.h>
#elif !defined(NOLIBDEFINES) && !defined(AMIGAGUIDE_NOLIBDEFINES)
# include <defines/amigaguide.h>
#endif

#endif /* PROTO_AMIGAGUIDE_H */
