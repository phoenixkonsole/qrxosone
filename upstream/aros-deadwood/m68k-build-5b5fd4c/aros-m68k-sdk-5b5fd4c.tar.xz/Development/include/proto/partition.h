#ifndef PROTO_PARTITION_H
#define PROTO_PARTITION_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/partition/partition.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/partition_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__PARTITION_NOLIBBASE__)
  #if !defined(PartitionBase)
   #ifdef __PARTITION_STDLIBBASE__
    extern struct Library *PartitionBase;
   #else
    extern struct PartitionBase *PartitionBase;
   #endif
  #endif
 #endif
 #ifndef __PARTITION_LIBBASE
  #define __PARTITION_LIBBASE (PartitionBase)
 #endif
#ifndef __aros_getbase_PartitionBase
extern struct PartitionBase *__aros_getbase_PartitionBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PARTITION_NOLIBINLINE)
# include <inline/partition.h>
#elif !defined(NOLIBDEFINES) && !defined(PARTITION_NOLIBDEFINES)
# include <defines/partition.h>
#endif

#endif /* PROTO_PARTITION_H */
