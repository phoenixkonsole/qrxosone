#ifndef PROTO_POTGO_H
#define PROTO_POTGO_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/m68k-amiga/potgo/potgo.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/potgo_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__POTGO_NOLIBBASE__)
  #if !defined(PotgoBase)
   extern struct Library *PotgoBase;
  #endif
 #endif
 #ifndef __POTGO_LIBBASE
  #define __POTGO_LIBBASE (PotgoBase)
 #endif
#ifndef __aros_getbase_PotgoBase
extern struct Library *__aros_getbase_PotgoBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(POTGO_NOLIBINLINE)
# include <inline/potgo.h>
#elif !defined(NOLIBDEFINES) && !defined(POTGO_NOLIBDEFINES)
# include <defines/potgo.h>
#endif

#endif /* PROTO_POTGO_H */
