#ifndef PROTO_GRAPHICS_H
#define PROTO_GRAPHICS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/graphics/graphics.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/graphics_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__GRAPHICS_NOLIBBASE__)
  #if !defined(GfxBase)
   #ifdef __GRAPHICS_STDLIBBASE__
    extern struct Library *GfxBase;
   #else
    extern struct GfxBase *GfxBase;
   #endif
  #endif
 #endif
 #ifndef __GRAPHICS_LIBBASE
  #define __GRAPHICS_LIBBASE (GfxBase)
 #endif
#ifndef __aros_getbase_GfxBase
extern struct GfxBase *__aros_getbase_GfxBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(GRAPHICS_NOLIBINLINE)
# include <inline/graphics.h>
#elif !defined(NOLIBDEFINES) && !defined(GRAPHICS_NOLIBDEFINES)
# include <defines/graphics.h>
#endif

#endif /* PROTO_GRAPHICS_H */
