#ifndef PROTO_MATHFFP_H
#define PROTO_MATHFFP_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/mathffp/mathffp.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/mathffp_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MATHFFP_NOLIBBASE__)
  #if !defined(MathBase)
   extern struct Library *MathBase;
  #endif
 #endif
 #ifndef __MATHFFP_LIBBASE
  #define __MATHFFP_LIBBASE (MathBase)
 #endif
#ifndef __aros_getbase_MathBase
extern struct Library *__aros_getbase_MathBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MATHFFP_NOLIBINLINE)
# include <inline/mathffp.h>
#elif !defined(NOLIBDEFINES) && !defined(MATHFFP_NOLIBDEFINES)
# include <defines/mathffp.h>
#endif

#endif /* PROTO_MATHFFP_H */
