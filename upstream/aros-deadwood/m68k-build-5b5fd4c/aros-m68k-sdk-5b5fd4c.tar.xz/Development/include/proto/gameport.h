#ifndef PROTO_GAMEPORT_H
#define PROTO_GAMEPORT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/devs/gameport/gameport.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/gameport_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__GAMEPORT_NOLIBBASE__)
  #if !defined(GPBase)
   #ifdef __GAMEPORT_STDLIBBASE__
    extern struct Library *GPBase;
   #else
    extern struct Device *GPBase;
   #endif
  #endif
 #endif
 #ifndef __GAMEPORT_LIBBASE
  #define __GAMEPORT_LIBBASE (GPBase)
 #endif
#ifndef __aros_getbase_GPBase
extern struct Device *__aros_getbase_GPBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(GAMEPORT_NOLIBINLINE)
# include <inline/gameport.h>
#elif !defined(NOLIBDEFINES) && !defined(GAMEPORT_NOLIBDEFINES)
# include <defines/gameport.h>
#endif

#endif /* PROTO_GAMEPORT_H */
