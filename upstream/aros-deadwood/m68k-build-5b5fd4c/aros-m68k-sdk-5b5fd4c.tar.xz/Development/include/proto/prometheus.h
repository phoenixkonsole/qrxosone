#ifndef PROTO_PROMETHEUS_H
#define PROTO_PROMETHEUS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/prometheus/prometheus.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/prometheus_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__PROMETHEUS_NOLIBBASE__)
  #if !defined(PrometheusBase)
   extern struct Library *PrometheusBase;
  #endif
 #endif
 #ifndef __PROMETHEUS_LIBBASE
  #define __PROMETHEUS_LIBBASE (PrometheusBase)
 #endif
#ifndef __aros_getbase_PrometheusBase
extern struct Library *__aros_getbase_PrometheusBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PROMETHEUS_NOLIBINLINE)
# include <inline/prometheus.h>
#elif !defined(NOLIBDEFINES) && !defined(PROMETHEUS_NOLIBDEFINES)
# include <defines/prometheus.h>
#endif

#endif /* PROTO_PROMETHEUS_H */
