#ifndef PROTO_LOWLEVEL_H
#define PROTO_LOWLEVEL_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/lowlevel/lowlevel.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/lowlevel_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__LOWLEVEL_NOLIBBASE__)
  #if !defined(LowLevelBase)
   extern struct Library *LowLevelBase;
  #endif
 #endif
 #ifndef __LOWLEVEL_LIBBASE
  #define __LOWLEVEL_LIBBASE (LowLevelBase)
 #endif
#ifndef __aros_getbase_LowLevelBase
extern struct Library *__aros_getbase_LowLevelBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(LOWLEVEL_NOLIBINLINE)
# include <inline/lowlevel.h>
#elif !defined(NOLIBDEFINES) && !defined(LOWLEVEL_NOLIBDEFINES)
# include <defines/lowlevel.h>
#endif

#endif /* PROTO_LOWLEVEL_H */
