#ifndef PROTO_BULLET_H
#define PROTO_BULLET_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/bullet/bullet.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/bullet_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__BULLET_NOLIBBASE__)
  #if !defined(BulletBase)
   extern struct Library *BulletBase;
  #endif
 #endif
 #ifndef __BULLET_LIBBASE
  #define __BULLET_LIBBASE (BulletBase)
 #endif
#ifndef __aros_getbase_BulletBase
extern struct Library *__aros_getbase_BulletBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(BULLET_NOLIBINLINE)
# include <inline/bullet.h>
#elif !defined(NOLIBDEFINES) && !defined(BULLET_NOLIBDEFINES)
# include <defines/bullet.h>
#endif

#endif /* PROTO_BULLET_H */
