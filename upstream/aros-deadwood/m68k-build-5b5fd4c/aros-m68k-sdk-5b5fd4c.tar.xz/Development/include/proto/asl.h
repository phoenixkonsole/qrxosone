#ifndef PROTO_ASL_H
#define PROTO_ASL_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/asl/asl.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/asl_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__ASL_NOLIBBASE__)
  #if !defined(AslBase)
   extern struct Library *AslBase;
  #endif
 #endif
 #ifndef __ASL_LIBBASE
  #define __ASL_LIBBASE (AslBase)
 #endif
#ifndef __aros_getbase_AslBase
extern struct Library *__aros_getbase_AslBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(ASL_NOLIBINLINE)
# include <inline/asl.h>
#elif !defined(NOLIBDEFINES) && !defined(ASL_NOLIBDEFINES)
# include <defines/asl.h>
#endif

#endif /* PROTO_ASL_H */
