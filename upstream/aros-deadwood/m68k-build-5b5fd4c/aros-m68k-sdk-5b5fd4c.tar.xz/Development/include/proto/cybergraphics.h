#ifndef PROTO_CYBERGRAPHICS_H
#define PROTO_CYBERGRAPHICS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/cgfx/cybergraphics.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/cybergraphics_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__CYBERGRAPHICS_NOLIBBASE__)
  #if !defined(CyberGfxBase)
   extern struct Library *CyberGfxBase;
  #endif
 #endif
 #ifndef __CYBERGRAPHICS_LIBBASE
  #define __CYBERGRAPHICS_LIBBASE (CyberGfxBase)
 #endif
#ifndef __aros_getbase_CyberGfxBase
extern struct Library *__aros_getbase_CyberGfxBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(CYBERGRAPHICS_NOLIBINLINE)
# include <inline/cybergraphics.h>
#elif !defined(NOLIBDEFINES) && !defined(CYBERGRAPHICS_NOLIBDEFINES)
# include <defines/cybergraphics.h>
#endif

#endif /* PROTO_CYBERGRAPHICS_H */
