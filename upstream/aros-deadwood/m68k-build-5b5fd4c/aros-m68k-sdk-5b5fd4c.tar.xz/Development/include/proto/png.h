#ifndef PROTO_PNG_H
#define PROTO_PNG_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/png/png.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/png_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__PNG_NOLIBBASE__)
  #if !defined(PngBase)
   extern struct Library *PngBase;
  #endif
 #endif
 #ifndef __PNG_LIBBASE
  #define __PNG_LIBBASE (PngBase)
 #endif
#ifndef __aros_getbase_PngBase
extern struct Library *__aros_getbase_PngBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PNG_NOLIBINLINE)
# include <inline/png.h>
#elif !defined(NOLIBDEFINES) && !defined(PNG_NOLIBDEFINES)
# include <defines/png.h>
#endif

#endif /* PROTO_PNG_H */
