#ifndef PROTO_EXPAT_H
#define PROTO_EXPAT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/expat/expat.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/expat_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__EXPAT_NOLIBBASE__)
  #if !defined(ExpatBase)
   extern struct Library *ExpatBase;
  #endif
 #endif
 #ifndef __EXPAT_LIBBASE
  #define __EXPAT_LIBBASE (ExpatBase)
 #endif
#ifndef __aros_getbase_ExpatBase
extern struct Library *__aros_getbase_ExpatBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(EXPAT_NOLIBINLINE)
# include <inline/expat.h>
#elif !defined(NOLIBDEFINES) && !defined(EXPAT_NOLIBDEFINES)
# include <defines/expat.h>
#endif

#endif /* PROTO_EXPAT_H */
