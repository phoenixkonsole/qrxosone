#ifndef PROTO_EFI_H
#define PROTO_EFI_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/all-native/efi/efi.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/efi_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__EFI_NOLIBBASE__)
  #if !defined(EFIBase)
   #ifdef __EFI_STDLIBBASE__
    extern struct Library *EFIBase;
   #else
    extern struct EFIBase *EFIBase;
   #endif
  #endif
 #endif
 #ifndef __EFI_LIBBASE
  #define __EFI_LIBBASE (EFIBase)
 #endif
#ifndef __aros_getbase_EFIBase
extern struct EFIBase *__aros_getbase_EFIBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(EFI_NOLIBINLINE)
# include <inline/efi.h>
#elif !defined(NOLIBDEFINES) && !defined(EFI_NOLIBDEFINES)
# include <defines/efi.h>
#endif

#endif /* PROTO_EFI_H */
