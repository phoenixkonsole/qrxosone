#ifndef PROTO_MUIMASTER_H
#define PROTO_MUIMASTER_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/muimaster/muimaster.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/muimaster_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MUIMASTER_NOLIBBASE__)
  #if !defined(MUIMasterBase)
   extern struct Library *MUIMasterBase;
  #endif
 #endif
 #ifndef __MUIMASTER_LIBBASE
  #define __MUIMASTER_LIBBASE (MUIMasterBase)
 #endif
#ifndef __aros_getbase_MUIMasterBase
extern struct Library *__aros_getbase_MUIMasterBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MUIMASTER_NOLIBINLINE)
# include <inline/muimaster.h>
#elif !defined(NOLIBDEFINES) && !defined(MUIMASTER_NOLIBDEFINES)
# include <defines/muimaster.h>
#endif

#endif /* PROTO_MUIMASTER_H */
