#ifndef PROTO_COLORWHEEL_H
#define PROTO_COLORWHEEL_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/classes/gadgets/colorwheel/colorwheel.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/colorwheel_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__COLORWHEEL_NOLIBBASE__)
  #if !defined(ColorWheelBase)
   extern struct Library *ColorWheelBase;
  #endif
 #endif
 #ifndef __COLORWHEEL_LIBBASE
  #define __COLORWHEEL_LIBBASE (ColorWheelBase)
 #endif
#ifndef __aros_getbase_ColorWheelBase
extern struct Library *__aros_getbase_ColorWheelBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(COLORWHEEL_NOLIBINLINE)
# include <inline/colorwheel.h>
#elif !defined(NOLIBDEFINES) && !defined(COLORWHEEL_NOLIBDEFINES)
# include <defines/colorwheel.h>
#endif

#endif /* PROTO_COLORWHEEL_H */
