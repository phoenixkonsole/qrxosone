#ifndef PROTO_PNGDT_H
#define PROTO_PNGDT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/classes/datatypes/png/png.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/pngdt_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__PNGDT_NOLIBBASE__)
  #if !defined(PNGBase)
   extern struct Library *PNGBase;
  #endif
 #endif
 #ifndef __PNGDT_LIBBASE
  #define __PNGDT_LIBBASE (PNGBase)
 #endif
#ifndef __aros_getbase_PNGBase
extern struct Library *__aros_getbase_PNGBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PNGDT_NOLIBINLINE)
# include <inline/pngdt.h>
#elif !defined(NOLIBDEFINES) && !defined(PNGDT_NOLIBDEFINES)
# include <defines/pngdt.h>
#endif

#endif /* PROTO_PNGDT_H */
