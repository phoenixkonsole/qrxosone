#ifndef PROTO_680X0_H
#define PROTO_680X0_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/m68k-all/m680x0/680x0.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/680x0_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__680X0_NOLIBBASE__)
  #if !defined(M680x0Base)
   extern struct Library *M680x0Base;
  #endif
 #endif
 #ifndef __680X0_LIBBASE
  #define __680X0_LIBBASE (M680x0Base)
 #endif
#ifndef __aros_getbase_M680x0Base
extern struct Library *__aros_getbase_M680x0Base(void);
#endif

#if !defined(NOLIBINLINE) && !defined(X680X0_NOLIBINLINE)
# include <inline/680x0.h>
#elif !defined(NOLIBDEFINES) && !defined(X680X0_NOLIBDEFINES)
# include <defines/680x0.h>
#endif

#endif /* PROTO_680X0_H */
