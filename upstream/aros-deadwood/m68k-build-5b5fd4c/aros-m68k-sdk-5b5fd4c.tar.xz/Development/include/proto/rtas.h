#ifndef PROTO_RTAS_H
#define PROTO_RTAS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/ppc-chrp/rtas/rtas.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/rtas_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__RTAS_NOLIBBASE__)
  #if !defined(RTASBase)
   #ifdef __RTAS_STDLIBBASE__
    extern struct Library *RTASBase;
   #else
    extern APTR RTASBase;
   #endif
  #endif
 #endif
 #ifndef __RTAS_LIBBASE
  #define __RTAS_LIBBASE (RTASBase)
 #endif
#ifndef __aros_getbase_RTASBase
extern APTR __aros_getbase_RTASBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(RTAS_NOLIBINLINE)
# include <inline/rtas.h>
#elif !defined(NOLIBDEFINES) && !defined(RTAS_NOLIBDEFINES)
# include <defines/rtas.h>
#endif

#endif /* PROTO_RTAS_H */
