#ifndef PROTO_CONSOLE_H
#define PROTO_CONSOLE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/devs/console/console.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/console_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__CONSOLE_NOLIBBASE__)
  #if !defined(ConsoleDevice)
   #ifdef __CONSOLE_STDLIBBASE__
    extern struct Library *ConsoleDevice;
   #else
    extern struct Device *ConsoleDevice;
   #endif
  #endif
 #endif
 #ifndef __CONSOLE_LIBBASE
  #define __CONSOLE_LIBBASE (ConsoleDevice)
 #endif
#ifndef __aros_getbase_ConsoleDevice
extern struct Device *__aros_getbase_ConsoleDevice(void);
#endif

#if !defined(NOLIBINLINE) && !defined(CONSOLE_NOLIBINLINE)
# include <inline/console.h>
#elif !defined(NOLIBDEFINES) && !defined(CONSOLE_NOLIBDEFINES)
# include <defines/console.h>
#endif

#endif /* PROTO_CONSOLE_H */
