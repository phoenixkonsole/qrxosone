#ifndef PROTO_UUID_H
#define PROTO_UUID_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/uuid/uuid.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/uuid_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__UUID_NOLIBBASE__)
  #if !defined(UUIDBase)
   extern struct Library *UUIDBase;
  #endif
 #endif
 #ifndef __UUID_LIBBASE
  #define __UUID_LIBBASE (UUIDBase)
 #endif
#ifndef __aros_getbase_UUIDBase
extern struct Library *__aros_getbase_UUIDBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(UUID_NOLIBINLINE)
# include <inline/uuid.h>
#elif !defined(NOLIBDEFINES) && !defined(UUID_NOLIBDEFINES)
# include <defines/uuid.h>
#endif

#endif /* PROTO_UUID_H */
