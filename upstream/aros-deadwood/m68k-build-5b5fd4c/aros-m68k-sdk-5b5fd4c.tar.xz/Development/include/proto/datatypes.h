#ifndef PROTO_DATATYPES_H
#define PROTO_DATATYPES_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/datatypes/datatypes.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/datatypes_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DATATYPES_NOLIBBASE__)
  #if !defined(DataTypesBase)
   extern struct Library *DataTypesBase;
  #endif
 #endif
 #ifndef __DATATYPES_LIBBASE
  #define __DATATYPES_LIBBASE (DataTypesBase)
 #endif
#ifndef __aros_getbase_DataTypesBase
extern struct Library *__aros_getbase_DataTypesBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DATATYPES_NOLIBINLINE)
# include <inline/datatypes.h>
#elif !defined(NOLIBDEFINES) && !defined(DATATYPES_NOLIBDEFINES)
# include <defines/datatypes.h>
#endif

#endif /* PROTO_DATATYPES_H */
