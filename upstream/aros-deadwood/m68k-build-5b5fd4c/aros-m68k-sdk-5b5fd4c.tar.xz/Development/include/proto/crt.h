#ifndef PROTO_CRT_H
#define PROTO_CRT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/compiler/crt/crt.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/crt_protos.h>

#ifndef __CRT_RELLIBBASE__
 #if !defined(__NOLIBBASE__) && !defined(__CRT_NOLIBBASE__)
  #if !defined(CrtBase)
   extern struct Library *CrtBase;
  #endif
 #endif
 #ifndef __CRT_LIBBASE
  #define __CRT_LIBBASE (CrtBase)
 #endif
#else /* __CRT_RELLIBASE__ */
 extern const IPTR __aros_rellib_offset_CrtBase;
 #define AROS_RELLIB_OFFSET_CRT __aros_rellib_offset_CrtBase
 #define AROS_RELLIB_BASE_CRT __aros_rellib_base_CrtBase
 #ifndef __CRT_LIBBASE
  #ifndef __aros_getoffsettable
   char *__aros_getoffsettable(void);
  #endif
  #define __CRT_LIBBASE (*(struct Library **)(__aros_getoffsettable()+__aros_rellib_offset_CrtBase))
 #endif
#endif
#ifndef __aros_getbase_CrtBase
extern struct Library *__aros_getbase_CrtBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(CRT_NOLIBINLINE) && !defined(__CRT_RELLIBBASE__)
# include <inline/crt.h>
#elif !defined(NOLIBDEFINES) && !defined(CRT_NOLIBDEFINES)
# include <defines/crt.h>
#endif

#endif /* PROTO_CRT_H */
