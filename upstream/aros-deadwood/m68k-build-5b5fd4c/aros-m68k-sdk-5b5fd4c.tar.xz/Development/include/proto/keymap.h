#ifndef PROTO_KEYMAP_H
#define PROTO_KEYMAP_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/keymap/keymap.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/keymap_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__KEYMAP_NOLIBBASE__)
  #if !defined(KeymapBase)
   extern struct Library *KeymapBase;
  #endif
 #endif
 #ifndef __KEYMAP_LIBBASE
  #define __KEYMAP_LIBBASE (KeymapBase)
 #endif
#ifndef __aros_getbase_KeymapBase
extern struct Library *__aros_getbase_KeymapBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(KEYMAP_NOLIBINLINE)
# include <inline/keymap.h>
#elif !defined(NOLIBDEFINES) && !defined(KEYMAP_NOLIBDEFINES)
# include <defines/keymap.h>
#endif

#endif /* PROTO_KEYMAP_H */
