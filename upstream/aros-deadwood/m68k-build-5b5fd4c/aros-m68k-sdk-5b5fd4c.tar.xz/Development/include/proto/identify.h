#ifndef PROTO_IDENTIFY_H
#define PROTO_IDENTIFY_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/identify/identify.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/identify_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__IDENTIFY_NOLIBBASE__)
  #if !defined(IdentifyBase)
   extern struct Library *IdentifyBase;
  #endif
 #endif
 #ifndef __IDENTIFY_LIBBASE
  #define __IDENTIFY_LIBBASE (IdentifyBase)
 #endif
#ifndef __aros_getbase_IdentifyBase
extern struct Library *__aros_getbase_IdentifyBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(IDENTIFY_NOLIBINLINE)
# include <inline/identify.h>
#elif !defined(NOLIBDEFINES) && !defined(IDENTIFY_NOLIBDEFINES)
# include <defines/identify.h>
#endif

#endif /* PROTO_IDENTIFY_H */
