#ifndef PROTO_TIFF_H
#define PROTO_TIFF_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/tiff/tiff.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/tiff_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__TIFF_NOLIBBASE__)
  #if !defined(TiffBase)
   extern struct Library *TiffBase;
  #endif
 #endif
 #ifndef __TIFF_LIBBASE
  #define __TIFF_LIBBASE (TiffBase)
 #endif
#ifndef __aros_getbase_TiffBase
extern struct Library *__aros_getbase_TiffBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(TIFF_NOLIBINLINE)
# include <inline/tiff.h>
#elif !defined(NOLIBDEFINES) && !defined(TIFF_NOLIBDEFINES)
# include <defines/tiff.h>
#endif

#endif /* PROTO_TIFF_H */
