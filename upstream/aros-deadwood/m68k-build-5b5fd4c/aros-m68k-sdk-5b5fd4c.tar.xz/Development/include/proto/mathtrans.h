#ifndef PROTO_MATHTRANS_H
#define PROTO_MATHTRANS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/mathtrans/mathtrans.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/mathtrans_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MATHTRANS_NOLIBBASE__)
  #if !defined(MathTransBase)
   extern struct Library *MathTransBase;
  #endif
 #endif
 #ifndef __MATHTRANS_LIBBASE
  #define __MATHTRANS_LIBBASE (MathTransBase)
 #endif
#ifndef __aros_getbase_MathTransBase
extern struct Library *__aros_getbase_MathTransBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MATHTRANS_NOLIBINLINE)
# include <inline/mathtrans.h>
#elif !defined(NOLIBDEFINES) && !defined(MATHTRANS_NOLIBDEFINES)
# include <defines/mathtrans.h>
#endif

#endif /* PROTO_MATHTRANS_H */
