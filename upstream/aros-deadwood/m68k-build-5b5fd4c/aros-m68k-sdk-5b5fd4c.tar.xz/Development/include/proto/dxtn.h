#ifndef PROTO_DXTN_H
#define PROTO_DXTN_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/dxtn/dxtn.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/dxtn_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DXTN_NOLIBBASE__)
  #if !defined(DXTNBase)
   extern struct Library *DXTNBase;
  #endif
 #endif
 #ifndef __DXTN_LIBBASE
  #define __DXTN_LIBBASE (DXTNBase)
 #endif
#ifndef __aros_getbase_DXTNBase
extern struct Library *__aros_getbase_DXTNBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DXTN_NOLIBINLINE)
# include <inline/dxtn.h>
#elif !defined(NOLIBDEFINES) && !defined(DXTN_NOLIBDEFINES)
# include <defines/dxtn.h>
#endif

#endif /* PROTO_DXTN_H */
