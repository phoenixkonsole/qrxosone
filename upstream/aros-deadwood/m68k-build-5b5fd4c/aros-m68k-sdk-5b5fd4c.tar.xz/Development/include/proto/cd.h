#ifndef PROTO_CD_H
#define PROTO_CD_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/m68k-amiga/devs/cd/cd.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/cd_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__CD_NOLIBBASE__)
  #if !defined(cdBase)
   #ifdef __CD_STDLIBBASE__
    extern struct Library *cdBase;
   #else
    extern struct Device *cdBase;
   #endif
  #endif
 #endif
 #ifndef __CD_LIBBASE
  #define __CD_LIBBASE (cdBase)
 #endif
#ifndef __aros_getbase_cdBase
extern struct Device *__aros_getbase_cdBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(CD_NOLIBINLINE)
# include <inline/cd.h>
#elif !defined(NOLIBDEFINES) && !defined(CD_NOLIBDEFINES)
# include <defines/cd.h>
#endif

#endif /* PROTO_CD_H */
