#ifndef PROTO_FREETYPE2_H
#define PROTO_FREETYPE2_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/freetype2/freetype2.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/freetype2_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__FREETYPE2_NOLIBBASE__)
  #if !defined(FreeType2Base)
   extern struct Library *FreeType2Base;
  #endif
 #endif
 #ifndef __FREETYPE2_LIBBASE
  #define __FREETYPE2_LIBBASE (FreeType2Base)
 #endif
#ifndef __aros_getbase_FreeType2Base
extern struct Library *__aros_getbase_FreeType2Base(void);
#endif

#if !defined(NOLIBINLINE) && !defined(FREETYPE2_NOLIBINLINE)
# include <inline/freetype2.h>
#elif !defined(NOLIBDEFINES) && !defined(FREETYPE2_NOLIBDEFINES)
# include <defines/freetype2.h>
#endif

#endif /* PROTO_FREETYPE2_H */
