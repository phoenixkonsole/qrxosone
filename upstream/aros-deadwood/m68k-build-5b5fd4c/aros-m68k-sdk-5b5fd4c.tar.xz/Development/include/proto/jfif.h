#ifndef PROTO_JFIF_H
#define PROTO_JFIF_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/jpeg/jfif.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/jfif_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__JFIF_NOLIBBASE__)
  #if !defined(JpegBase)
   extern struct Library *JpegBase;
  #endif
 #endif
 #ifndef __JFIF_LIBBASE
  #define __JFIF_LIBBASE (JpegBase)
 #endif
#ifndef __aros_getbase_JpegBase
extern struct Library *__aros_getbase_JpegBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(JFIF_NOLIBINLINE)
# include <inline/jfif.h>
#elif !defined(NOLIBDEFINES) && !defined(JFIF_NOLIBDEFINES)
# include <defines/jfif.h>
#endif

#endif /* PROTO_JFIF_H */
