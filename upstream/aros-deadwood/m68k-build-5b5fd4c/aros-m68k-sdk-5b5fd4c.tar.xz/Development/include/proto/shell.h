#ifndef PROTO_SHELL_H
#define PROTO_SHELL_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/c/Shell/shell.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/shell_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__SHELL_NOLIBBASE__)
  #if !defined(Shell)
   #ifdef __SHELL_STDLIBBASE__
    extern struct Library *Shell;
   #else
    extern APTR Shell;
   #endif
  #endif
 #endif
 #ifndef __SHELL_LIBBASE
  #define __SHELL_LIBBASE (Shell)
 #endif
#ifndef __aros_getbase_Shell
extern APTR __aros_getbase_Shell(void);
#endif

#if !defined(NOLIBINLINE) && !defined(SHELL_NOLIBINLINE)
# include <inline/shell.h>
#elif !defined(NOLIBDEFINES) && !defined(SHELL_NOLIBDEFINES)
# include <defines/shell.h>
#endif

#endif /* PROTO_SHELL_H */
