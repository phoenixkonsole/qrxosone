#ifndef PROTO_EXPANSION_H
#define PROTO_EXPANSION_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/expansion/expansion.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/expansion_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__EXPANSION_NOLIBBASE__)
  #if !defined(ExpansionBase)
   extern struct Library *ExpansionBase;
  #endif
 #endif
 #ifndef __EXPANSION_LIBBASE
  #define __EXPANSION_LIBBASE (ExpansionBase)
 #endif
#ifndef __aros_getbase_ExpansionBase
extern struct Library *__aros_getbase_ExpansionBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(EXPANSION_NOLIBINLINE)
# include <inline/expansion.h>
#elif !defined(NOLIBDEFINES) && !defined(EXPANSION_NOLIBDEFINES)
# include <defines/expansion.h>
#endif

#endif /* PROTO_EXPANSION_H */
