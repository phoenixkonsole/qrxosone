#ifndef PROTO_REXXSYSLIB_H
#define PROTO_REXXSYSLIB_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/rexxsyslib/rexxsyslib.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/rexxsyslib_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__REXXSYSLIB_NOLIBBASE__)
  #if !defined(RexxSysBase)
   #ifdef __REXXSYSLIB_STDLIBBASE__
    extern struct Library *RexxSysBase;
   #else
    extern struct RxsLib *RexxSysBase;
   #endif
  #endif
 #endif
 #ifndef __REXXSYSLIB_LIBBASE
  #define __REXXSYSLIB_LIBBASE (RexxSysBase)
 #endif
#ifndef __aros_getbase_RexxSysBase
extern struct RxsLib *__aros_getbase_RexxSysBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(REXXSYSLIB_NOLIBINLINE)
# include <inline/rexxsyslib.h>
#elif !defined(NOLIBDEFINES) && !defined(REXXSYSLIB_NOLIBDEFINES)
# include <defines/rexxsyslib.h>
#endif

#endif /* PROTO_REXXSYSLIB_H */
