#ifndef PROTO_NONVOLATILE_H
#define PROTO_NONVOLATILE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/nonvolatile/nonvolatile.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/nonvolatile_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__NONVOLATILE_NOLIBBASE__)
  #if !defined(NonvolatileBase)
   extern struct Library *NonvolatileBase;
  #endif
 #endif
 #ifndef __NONVOLATILE_LIBBASE
  #define __NONVOLATILE_LIBBASE (NonvolatileBase)
 #endif
#ifndef __aros_getbase_NonvolatileBase
extern struct Library *__aros_getbase_NonvolatileBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(NONVOLATILE_NOLIBINLINE)
# include <inline/nonvolatile.h>
#elif !defined(NOLIBDEFINES) && !defined(NONVOLATILE_NOLIBDEFINES)
# include <defines/nonvolatile.h>
#endif

#endif /* PROTO_NONVOLATILE_H */
