#ifndef PROTO_GADTOOLS_H
#define PROTO_GADTOOLS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/gadtools/gadtools.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/gadtools_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__GADTOOLS_NOLIBBASE__)
  #if !defined(GadToolsBase)
   extern struct Library *GadToolsBase;
  #endif
 #endif
 #ifndef __GADTOOLS_LIBBASE
  #define __GADTOOLS_LIBBASE (GadToolsBase)
 #endif
#ifndef __aros_getbase_GadToolsBase
extern struct Library *__aros_getbase_GadToolsBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(GADTOOLS_NOLIBINLINE)
# include <inline/gadtools.h>
#elif !defined(NOLIBDEFINES) && !defined(GADTOOLS_NOLIBDEFINES)
# include <defines/gadtools.h>
#endif

#endif /* PROTO_GADTOOLS_H */
