#ifndef PROTO_PROCESSOR_H
#define PROTO_PROCESSOR_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/processor/processor.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/processor_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__PROCESSOR_NOLIBBASE__)
  #if !defined(ProcessorBase)
   #ifdef __PROCESSOR_STDLIBBASE__
    extern struct Library *ProcessorBase;
   #else
    extern APTR ProcessorBase;
   #endif
  #endif
 #endif
 #ifndef __PROCESSOR_LIBBASE
  #define __PROCESSOR_LIBBASE (ProcessorBase)
 #endif
#ifndef __aros_getbase_ProcessorBase
extern APTR __aros_getbase_ProcessorBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PROCESSOR_NOLIBINLINE)
# include <inline/processor.h>
#elif !defined(NOLIBDEFINES) && !defined(PROCESSOR_NOLIBDEFINES)
# include <defines/processor.h>
#endif

#endif /* PROTO_PROCESSOR_H */
