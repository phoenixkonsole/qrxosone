#ifndef PROTO_LAYERS_H
#define PROTO_LAYERS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/hyperlayers/layers.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/layers_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__LAYERS_NOLIBBASE__)
  #if !defined(LayersBase)
   extern struct Library *LayersBase;
  #endif
 #endif
 #ifndef __LAYERS_LIBBASE
  #define __LAYERS_LIBBASE (LayersBase)
 #endif
#ifndef __aros_getbase_LayersBase
extern struct Library *__aros_getbase_LayersBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(LAYERS_NOLIBINLINE)
# include <inline/layers.h>
#elif !defined(NOLIBDEFINES) && !defined(LAYERS_NOLIBDEFINES)
# include <defines/layers.h>
#endif

#endif /* PROTO_LAYERS_H */
