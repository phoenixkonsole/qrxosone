#ifndef PROTO_MISC_H
#define PROTO_MISC_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/misc/misc.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/misc_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MISC_NOLIBBASE__)
  #if !defined(MiscBase)
   #ifdef __MISC_STDLIBBASE__
    extern struct Library *MiscBase;
   #else
    extern APTR MiscBase;
   #endif
  #endif
 #endif
 #ifndef __MISC_LIBBASE
  #define __MISC_LIBBASE (MiscBase)
 #endif
#ifndef __aros_getbase_MiscBase
extern APTR __aros_getbase_MiscBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MISC_NOLIBINLINE)
# include <inline/misc.h>
#elif !defined(NOLIBDEFINES) && !defined(MISC_NOLIBDEFINES)
# include <defines/misc.h>
#endif

#endif /* PROTO_MISC_H */
