#ifndef PROTO_STDLIB_H
#define PROTO_STDLIB_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/compiler/crt/stdlib.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/stdlib_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__STDLIB_NOLIBBASE__)
  #if !defined(StdlibBase)
   #ifdef __STDLIB_STDLIBBASE__
    extern struct Library *StdlibBase;
   #else
    extern struct StdlibBase *StdlibBase;
   #endif
  #endif
 #endif
 #ifndef __STDLIB_LIBBASE
  #define __STDLIB_LIBBASE (StdlibBase)
 #endif
#ifndef __aros_getbase_StdlibBase
extern struct StdlibBase *__aros_getbase_StdlibBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(STDLIB_NOLIBINLINE)
# include <inline/stdlib.h>
#elif !defined(NOLIBDEFINES) && !defined(STDLIB_NOLIBDEFINES)
# include <defines/stdlib.h>
#endif

#endif /* PROTO_STDLIB_H */
