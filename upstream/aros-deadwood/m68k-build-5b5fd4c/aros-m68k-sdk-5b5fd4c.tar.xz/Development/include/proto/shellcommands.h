#ifndef PROTO_SHELLCOMMANDS_H
#define PROTO_SHELLCOMMANDS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/c/shellcommands/shellcommands.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/shellcommands_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__SHELLCOMMANDS_NOLIBBASE__)
  #if !defined(ShellCommandsBase)
   #ifdef __SHELLCOMMANDS_STDLIBBASE__
    extern struct Library *ShellCommandsBase;
   #else
    extern APTR ShellCommandsBase;
   #endif
  #endif
 #endif
 #ifndef __SHELLCOMMANDS_LIBBASE
  #define __SHELLCOMMANDS_LIBBASE (ShellCommandsBase)
 #endif
#ifndef __aros_getbase_ShellCommandsBase
extern APTR __aros_getbase_ShellCommandsBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(SHELLCOMMANDS_NOLIBINLINE)
# include <inline/shellcommands.h>
#elif !defined(NOLIBDEFINES) && !defined(SHELLCOMMANDS_NOLIBDEFINES)
# include <defines/shellcommands.h>
#endif

#endif /* PROTO_SHELLCOMMANDS_H */
