#ifndef PROTO_OPENFIRMWARE_H
#define PROTO_OPENFIRMWARE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/openfirmware/openfirmware.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/openfirmware_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__OPENFIRMWARE_NOLIBBASE__)
  #if !defined(OpenFirmwareBase)
   #ifdef __OPENFIRMWARE_STDLIBBASE__
    extern struct Library *OpenFirmwareBase;
   #else
    extern APTR OpenFirmwareBase;
   #endif
  #endif
 #endif
 #ifndef __OPENFIRMWARE_LIBBASE
  #define __OPENFIRMWARE_LIBBASE (OpenFirmwareBase)
 #endif
#ifndef __aros_getbase_OpenFirmwareBase
extern APTR __aros_getbase_OpenFirmwareBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(OPENFIRMWARE_NOLIBINLINE)
# include <inline/openfirmware.h>
#elif !defined(NOLIBDEFINES) && !defined(OPENFIRMWARE_NOLIBDEFINES)
# include <defines/openfirmware.h>
#endif

#endif /* PROTO_OPENFIRMWARE_H */
