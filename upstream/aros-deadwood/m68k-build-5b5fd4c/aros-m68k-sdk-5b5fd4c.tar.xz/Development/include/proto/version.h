#ifndef PROTO_VERSION_H
#define PROTO_VERSION_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/version/version.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/version_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__VERSION_NOLIBBASE__)
  #if !defined(VersionBase)
   extern struct Library *VersionBase;
  #endif
 #endif
 #ifndef __VERSION_LIBBASE
  #define __VERSION_LIBBASE (VersionBase)
 #endif
#ifndef __aros_getbase_VersionBase
extern struct Library *__aros_getbase_VersionBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(VERSION_NOLIBINLINE)
# include <inline/version.h>
#elif !defined(NOLIBDEFINES) && !defined(VERSION_NOLIBDEFINES)
# include <defines/version.h>
#endif

#endif /* PROTO_VERSION_H */
