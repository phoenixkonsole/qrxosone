#ifndef PROTO_CARDRES_H
#define PROTO_CARDRES_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/card/card.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/cardres_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__CARDRES_NOLIBBASE__)
  #if !defined(CardResource)
   extern struct Library *CardResource;
  #endif
 #endif
 #ifndef __CARDRES_LIBBASE
  #define __CARDRES_LIBBASE (CardResource)
 #endif
#ifndef __aros_getbase_CardResource
extern struct Library *__aros_getbase_CardResource(void);
#endif

#if !defined(NOLIBINLINE) && !defined(CARDRES_NOLIBINLINE)
# include <inline/cardres.h>
#elif !defined(NOLIBDEFINES) && !defined(CARDRES_NOLIBDEFINES)
# include <defines/cardres.h>
#endif

#endif /* PROTO_CARDRES_H */
