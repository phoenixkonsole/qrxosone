#ifndef PROTO_INPUT_H
#define PROTO_INPUT_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/devs/input/input.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/input_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__INPUT_NOLIBBASE__)
  #if !defined(InputBase)
   #ifdef __INPUT_STDLIBBASE__
    extern struct Library *InputBase;
   #else
    extern struct Device *InputBase;
   #endif
  #endif
 #endif
 #ifndef __INPUT_LIBBASE
  #define __INPUT_LIBBASE (InputBase)
 #endif
#ifndef __aros_getbase_InputBase
extern struct Device *__aros_getbase_InputBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(INPUT_NOLIBINLINE)
# include <inline/input.h>
#elif !defined(NOLIBDEFINES) && !defined(INPUT_NOLIBDEFINES)
# include <defines/input.h>
#endif

#endif /* PROTO_INPUT_H */
