#ifndef PROTO_GLU_H
#define PROTO_GLU_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/glu/glu.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/glu_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__GLU_NOLIBBASE__)
  #if !defined(GLUBase)
   extern struct Library *GLUBase;
  #endif
 #endif
 #ifndef __GLU_LIBBASE
  #define __GLU_LIBBASE (GLUBase)
 #endif
#ifndef __aros_getbase_GLUBase
extern struct Library *__aros_getbase_GLUBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(GLU_NOLIBINLINE)
# include <inline/glu.h>
#elif !defined(NOLIBDEFINES) && !defined(GLU_NOLIBDEFINES)
# include <defines/glu.h>
#endif

#endif /* PROTO_GLU_H */
