#ifndef PROTO_POSEIDON_H
#define PROTO_POSEIDON_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/usb/poseidon/poseidon.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/poseidon_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__POSEIDON_NOLIBBASE__)
  #if !defined(ps)
   extern struct Library *ps;
  #endif
 #endif
 #ifndef __POSEIDON_LIBBASE
  #define __POSEIDON_LIBBASE (ps)
 #endif
#ifndef __aros_getbase_ps
extern struct Library *__aros_getbase_ps(void);
#endif

#if !defined(NOLIBINLINE) && !defined(POSEIDON_NOLIBINLINE)
# include <inline/poseidon.h>
#elif !defined(NOLIBDEFINES) && !defined(POSEIDON_NOLIBDEFINES)
# include <defines/poseidon.h>
#endif

#endif /* PROTO_POSEIDON_H */
