#ifndef PROTO_WORKBOOK_H
#define PROTO_WORKBOOK_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/system/Workbook/workbook.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/workbook_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__WORKBOOK_NOLIBBASE__)
  #if !defined(WorkbookBase)
   #ifdef __WORKBOOK_STDLIBBASE__
    extern struct Library *WorkbookBase;
   #else
    extern APTR WorkbookBase;
   #endif
  #endif
 #endif
 #ifndef __WORKBOOK_LIBBASE
  #define __WORKBOOK_LIBBASE (WorkbookBase)
 #endif
#ifndef __aros_getbase_WorkbookBase
extern APTR __aros_getbase_WorkbookBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(WORKBOOK_NOLIBINLINE)
# include <inline/workbook.h>
#elif !defined(NOLIBDEFINES) && !defined(WORKBOOK_NOLIBDEFINES)
# include <defines/workbook.h>
#endif

#endif /* PROTO_WORKBOOK_H */
