#ifndef PROTO_INTUITION_H
#define PROTO_INTUITION_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/intuition/intuition.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/intuition_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__INTUITION_NOLIBBASE__)
  #if !defined(IntuitionBase)
   #ifdef __INTUITION_STDLIBBASE__
    extern struct Library *IntuitionBase;
   #else
    extern struct IntuitionBase *IntuitionBase;
   #endif
  #endif
 #endif
 #ifndef __INTUITION_LIBBASE
  #define __INTUITION_LIBBASE (IntuitionBase)
 #endif
#ifndef __aros_getbase_IntuitionBase
extern struct IntuitionBase *__aros_getbase_IntuitionBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(INTUITION_NOLIBINLINE)
# include <inline/intuition.h>
#elif !defined(NOLIBDEFINES) && !defined(INTUITION_NOLIBDEFINES)
# include <defines/intuition.h>
#endif

#endif /* PROTO_INTUITION_H */
