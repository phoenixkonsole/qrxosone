#ifndef PROTO_FREEANIM_H
#define PROTO_FREEANIM_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/m68k-amiga/freeanim/freeanim.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/freeanim_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__FREEANIM_NOLIBBASE__)
  #if !defined(FreeAnimBase)
   extern struct Library *FreeAnimBase;
  #endif
 #endif
 #ifndef __FREEANIM_LIBBASE
  #define __FREEANIM_LIBBASE (FreeAnimBase)
 #endif
#ifndef __aros_getbase_FreeAnimBase
extern struct Library *__aros_getbase_FreeAnimBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(FREEANIM_NOLIBINLINE)
# include <inline/freeanim.h>
#elif !defined(NOLIBDEFINES) && !defined(FREEANIM_NOLIBDEFINES)
# include <defines/freeanim.h>
#endif

#endif /* PROTO_FREEANIM_H */
