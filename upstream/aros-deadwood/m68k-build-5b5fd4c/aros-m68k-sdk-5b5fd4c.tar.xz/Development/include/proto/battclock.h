#ifndef PROTO_BATTCLOCK_H
#define PROTO_BATTCLOCK_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/battclock/battclock.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/battclock_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__BATTCLOCK_NOLIBBASE__)
  #if !defined(BattClockBase)
   extern struct Library *BattClockBase;
  #endif
 #endif
 #ifndef __BATTCLOCK_LIBBASE
  #define __BATTCLOCK_LIBBASE (BattClockBase)
 #endif
#ifndef __aros_getbase_BattClockBase
extern struct Library *__aros_getbase_BattClockBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(BATTCLOCK_NOLIBINLINE)
# include <inline/battclock.h>
#elif !defined(NOLIBDEFINES) && !defined(BATTCLOCK_NOLIBDEFINES)
# include <defines/battclock.h>
#endif

#endif /* PROTO_BATTCLOCK_H */
