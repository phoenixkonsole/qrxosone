#ifndef PROTO_LZMA_H
#define PROTO_LZMA_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/lzma/lzma.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/lzma_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__LZMA_NOLIBBASE__)
  #if !defined(XZBase)
   extern struct Library *XZBase;
  #endif
 #endif
 #ifndef __LZMA_LIBBASE
  #define __LZMA_LIBBASE (XZBase)
 #endif
#ifndef __aros_getbase_XZBase
extern struct Library *__aros_getbase_XZBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(LZMA_NOLIBINLINE)
# include <inline/lzma.h>
#elif !defined(NOLIBDEFINES) && !defined(LZMA_NOLIBDEFINES)
# include <defines/lzma.h>
#endif

#endif /* PROTO_LZMA_H */
