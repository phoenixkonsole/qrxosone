#ifndef PROTO_USBCLASS_H
#define PROTO_USBCLASS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/usb/classes/usbclass.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/usbclass_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__USBCLASS_NOLIBBASE__)
  #if !defined(UsbClsBase)
   extern struct Library *UsbClsBase;
  #endif
 #endif
 #ifndef __USBCLASS_LIBBASE
  #define __USBCLASS_LIBBASE (UsbClsBase)
 #endif
#ifndef __aros_getbase_UsbClsBase
extern struct Library *__aros_getbase_UsbClsBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(USBCLASS_NOLIBINLINE)
# include <inline/usbclass.h>
#elif !defined(NOLIBDEFINES) && !defined(USBCLASS_NOLIBDEFINES)
# include <defines/usbclass.h>
#endif

#endif /* PROTO_USBCLASS_H */
