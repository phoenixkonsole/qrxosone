#ifndef PROTO_LOCALE_H
#define PROTO_LOCALE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/locale/locale.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/locale_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__LOCALE_NOLIBBASE__)
  #if !defined(LocaleBase)
   #ifdef __LOCALE_STDLIBBASE__
    extern struct Library *LocaleBase;
   #else
    extern struct LocaleBase *LocaleBase;
   #endif
  #endif
 #endif
 #ifndef __LOCALE_LIBBASE
  #define __LOCALE_LIBBASE (LocaleBase)
 #endif
#ifndef __aros_getbase_LocaleBase
extern struct LocaleBase *__aros_getbase_LocaleBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(LOCALE_NOLIBINLINE)
# include <inline/locale.h>
#elif !defined(NOLIBDEFINES) && !defined(LOCALE_NOLIBDEFINES)
# include <defines/locale.h>
#endif

#endif /* PROTO_LOCALE_H */
