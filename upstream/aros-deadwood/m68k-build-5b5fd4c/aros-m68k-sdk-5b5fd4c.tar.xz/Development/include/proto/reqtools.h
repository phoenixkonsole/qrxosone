#ifndef PROTO_REQTOOLS_H
#define PROTO_REQTOOLS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/reqtools/reqtools.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/reqtools_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__REQTOOLS_NOLIBBASE__)
  #if !defined(ReqToolsBase)
   #ifdef __REQTOOLS_STDLIBBASE__
    extern struct Library *ReqToolsBase;
   #else
    extern struct ReqToolsBase *ReqToolsBase;
   #endif
  #endif
 #endif
 #ifndef __REQTOOLS_LIBBASE
  #define __REQTOOLS_LIBBASE (ReqToolsBase)
 #endif
#ifndef __aros_getbase_ReqToolsBase
extern struct ReqToolsBase *__aros_getbase_ReqToolsBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(REQTOOLS_NOLIBINLINE)
# include <inline/reqtools.h>
#elif !defined(NOLIBDEFINES) && !defined(REQTOOLS_NOLIBDEFINES)
# include <defines/reqtools.h>
#endif

#endif /* PROTO_REQTOOLS_H */
