#ifndef PROTO_COOLIMAGES_H
#define PROTO_COOLIMAGES_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/coolimages/coolimages.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/coolimages_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__COOLIMAGES_NOLIBBASE__)
  #if !defined(CoolImagesBase)
   extern struct Library *CoolImagesBase;
  #endif
 #endif
 #ifndef __COOLIMAGES_LIBBASE
  #define __COOLIMAGES_LIBBASE (CoolImagesBase)
 #endif
#ifndef __aros_getbase_CoolImagesBase
extern struct Library *__aros_getbase_CoolImagesBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(COOLIMAGES_NOLIBINLINE)
# include <inline/coolimages.h>
#elif !defined(NOLIBDEFINES) && !defined(COOLIMAGES_NOLIBDEFINES)
# include <defines/coolimages.h>
#endif

#endif /* PROTO_COOLIMAGES_H */
