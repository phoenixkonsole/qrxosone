#ifndef PROTO_SETPATCH_H
#define PROTO_SETPATCH_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/m68k-amiga/setpatch/setpatch.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/setpatch_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__SETPATCH_NOLIBBASE__)
  #if !defined(SetPatchBase)
   extern struct Library *SetPatchBase;
  #endif
 #endif
 #ifndef __SETPATCH_LIBBASE
  #define __SETPATCH_LIBBASE (SetPatchBase)
 #endif
#ifndef __aros_getbase_SetPatchBase
extern struct Library *__aros_getbase_SetPatchBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(SETPATCH_NOLIBINLINE)
# include <inline/setpatch.h>
#elif !defined(NOLIBDEFINES) && !defined(SETPATCH_NOLIBDEFINES)
# include <defines/setpatch.h>
#endif

#endif /* PROTO_SETPATCH_H */
