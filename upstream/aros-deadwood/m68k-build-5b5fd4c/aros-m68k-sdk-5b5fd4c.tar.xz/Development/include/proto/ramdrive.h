#ifndef PROTO_RAMDRIVE_H
#define PROTO_RAMDRIVE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/devs/ramdrive.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <exec/devices.h>
#include <aros/system.h>

#include <clib/ramdrive_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__RAMDRIVE_NOLIBBASE__)
  #if !defined(RamdriveBase)
   #ifdef __RAMDRIVE_STDLIBBASE__
    extern struct Library *RamdriveBase;
   #else
    extern struct Device *RamdriveBase;
   #endif
  #endif
 #endif
 #ifndef __RAMDRIVE_LIBBASE
  #define __RAMDRIVE_LIBBASE (RamdriveBase)
 #endif
#ifndef __aros_getbase_RamdriveBase
extern struct Device *__aros_getbase_RamdriveBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(RAMDRIVE_NOLIBINLINE)
# include <inline/ramdrive.h>
#elif !defined(NOLIBDEFINES) && !defined(RAMDRIVE_NOLIBDEFINES)
# include <defines/ramdrive.h>
#endif

#endif /* PROTO_RAMDRIVE_H */
