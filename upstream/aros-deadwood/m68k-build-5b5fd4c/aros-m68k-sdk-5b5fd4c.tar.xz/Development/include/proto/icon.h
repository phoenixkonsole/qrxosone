#ifndef PROTO_ICON_H
#define PROTO_ICON_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/icon/icon.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/icon_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__ICON_NOLIBBASE__)
  #if !defined(IconBase)
   extern struct Library *IconBase;
  #endif
 #endif
 #ifndef __ICON_LIBBASE
  #define __ICON_LIBBASE (IconBase)
 #endif
#ifndef __aros_getbase_IconBase
extern struct Library *__aros_getbase_IconBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(ICON_NOLIBINLINE)
# include <inline/icon.h>
#elif !defined(NOLIBDEFINES) && !defined(ICON_NOLIBDEFINES)
# include <defines/icon.h>
#endif

#endif /* PROTO_ICON_H */
