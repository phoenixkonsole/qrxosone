#ifndef PROTO_DISK_H
#define PROTO_DISK_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/rom/disk/disk.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/disk_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DISK_NOLIBBASE__)
  #if !defined(DiskBase)
   extern struct Library *DiskBase;
  #endif
 #endif
 #ifndef __DISK_LIBBASE
  #define __DISK_LIBBASE (DiskBase)
 #endif
#ifndef __aros_getbase_DiskBase
extern struct Library *__aros_getbase_DiskBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DISK_NOLIBINLINE)
# include <inline/disk.h>
#elif !defined(NOLIBDEFINES) && !defined(DISK_NOLIBDEFINES)
# include <defines/disk.h>
#endif

#endif /* PROTO_DISK_H */
