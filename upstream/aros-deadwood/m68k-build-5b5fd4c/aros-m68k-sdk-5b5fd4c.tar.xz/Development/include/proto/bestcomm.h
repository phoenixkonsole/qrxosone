#ifndef PROTO_BESTCOMM_H
#define PROTO_BESTCOMM_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/arch/ppc-chrp/efika/bestcomm/bestcomm.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/bestcomm_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__BESTCOMM_NOLIBBASE__)
  #if !defined(BestCommBase)
   #ifdef __BESTCOMM_STDLIBBASE__
    extern struct Library *BestCommBase;
   #else
    extern APTR BestCommBase;
   #endif
  #endif
 #endif
 #ifndef __BESTCOMM_LIBBASE
  #define __BESTCOMM_LIBBASE (BestCommBase)
 #endif
#ifndef __aros_getbase_BestCommBase
extern APTR __aros_getbase_BestCommBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(BESTCOMM_NOLIBINLINE)
# include <inline/bestcomm.h>
#elif !defined(NOLIBDEFINES) && !defined(BESTCOMM_NOLIBDEFINES)
# include <defines/bestcomm.h>
#endif

#endif /* PROTO_BESTCOMM_H */
