#ifndef PROTO_BZ2_H
#define PROTO_BZ2_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/external/bz2/bz2.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/bz2_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__BZ2_NOLIBBASE__)
  #if !defined(BZ2Base)
   extern struct Library *BZ2Base;
  #endif
 #endif
 #ifndef __BZ2_LIBBASE
  #define __BZ2_LIBBASE (BZ2Base)
 #endif
#ifndef __aros_getbase_BZ2Base
extern struct Library *__aros_getbase_BZ2Base(void);
#endif

#if !defined(NOLIBINLINE) && !defined(BZ2_NOLIBINLINE)
# include <inline/bz2.h>
#elif !defined(NOLIBDEFINES) && !defined(BZ2_NOLIBDEFINES)
# include <defines/bz2.h>
#endif

#endif /* PROTO_BZ2_H */
