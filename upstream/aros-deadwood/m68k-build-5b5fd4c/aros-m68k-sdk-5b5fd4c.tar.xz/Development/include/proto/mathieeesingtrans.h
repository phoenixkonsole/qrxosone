#ifndef PROTO_MATHIEEESINGTRANS_H
#define PROTO_MATHIEEESINGTRANS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/workbench/libs/mathieeesingtrans/mathieeesingtrans.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/mathieeesingtrans_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__MATHIEEESINGTRANS_NOLIBBASE__)
  #if !defined(MathIeeeSingTransBase)
   extern struct Library *MathIeeeSingTransBase;
  #endif
 #endif
 #ifndef __MATHIEEESINGTRANS_LIBBASE
  #define __MATHIEEESINGTRANS_LIBBASE (MathIeeeSingTransBase)
 #endif
#ifndef __aros_getbase_MathIeeeSingTransBase
extern struct Library *__aros_getbase_MathIeeeSingTransBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(MATHIEEESINGTRANS_NOLIBINLINE)
# include <inline/mathieeesingtrans.h>
#elif !defined(NOLIBDEFINES) && !defined(MATHIEEESINGTRANS_NOLIBDEFINES)
# include <defines/mathieeesingtrans.h>
#endif

#endif /* PROTO_MATHIEEESINGTRANS_H */
