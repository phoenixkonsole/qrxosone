#ifndef DEFINES_SINGLE_H
#define DEFINES_SINGLE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/single.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Defines for single
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__SINGLE_LIBBASE)
#define __SINGLE_LIBBASE __aros_getbase_SingleBase()
#endif
#ifndef __aros_getbase_SingleBase
extern struct Library *__aros_getbase_SingleBase(void);
#endif

__BEGIN_DECLS


#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegSetValue_WB(__SingleBase, __arg1) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LC1NR(void, RegSetValue,\
         AROS_LCA(LONG, (__arg1), D0), \
        struct Library *, (__SingleBase), 5, Single);\
})

#define RegSetValue(arg1) \
    __RegSetValue_WB(__SINGLE_LIBBASE, (arg1))

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegAdd4_WB(__SingleBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LC4(LONG, RegAdd4,\
         AROS_LCA(LONG, (__arg1), D0), \
         AROS_LCA(LONG, (__arg2), D1), \
         AROS_LCA(LONG, (__arg3), D2), \
         AROS_LCA(LONG, (__arg4), D3), \
        struct Library *, (__SingleBase), 6, Single);\
})

#define RegAdd4(arg1, arg2, arg3, arg4) \
    __RegAdd4_WB(__SINGLE_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegAdd6_WB(__SingleBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LC6(LONG, RegAdd6,\
         AROS_LCA(LONG, (__arg1), D0), \
         AROS_LCA(LONG, (__arg2), D1), \
         AROS_LCA(LONG, (__arg3), D2), \
         AROS_LCA(LONG, (__arg4), D3), \
         AROS_LCA(LONG, (__arg5), D4), \
         AROS_LCA(LONG, (__arg6), D5), \
        struct Library *, (__SingleBase), 7, Single);\
})

#define RegAdd6(arg1, arg2, arg3, arg4, arg5, arg6) \
    __RegAdd6_WB(__SINGLE_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6))

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegAdd9_WB(__SingleBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7, __arg8, __arg9) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LC9(LONG, RegAdd9,\
         AROS_LCA(LONG, (__arg1), D0), \
         AROS_LCA(LONG, (__arg2), D1), \
         AROS_LCA(LONG, (__arg3), D2), \
         AROS_LCA(LONG, (__arg4), D3), \
         AROS_LCA(LONG, (__arg5), D4), \
         AROS_LCA(LONG, (__arg6), D5), \
         AROS_LCA(LONG, (__arg7), D6), \
         AROS_LCA(LONG, (__arg8), D7), \
         AROS_LCA(LONG, (__arg9), A0), \
        struct Library *, (__SingleBase), 8, Single);\
})

#define RegAdd9(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9) \
    __RegAdd9_WB(__SINGLE_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8), (arg9))

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegReturnMinusPi_WB(__SingleBase) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LC0(double, RegReturnMinusPi,\
        struct Library *, (__SingleBase), 9, Single);\
})

#define RegReturnMinusPi() \
    __RegReturnMinusPi_WB(__SINGLE_LIBBASE)

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegAddDouble2_WB(__SingleBase, __arg1, __arg2) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LCDOUBLE2(double, RegAddDouble2,\
         AROS_LCA2(double, (__arg1), D0, D1), \
         AROS_LCA2(double, (__arg2), D2, D3), \
        struct Library *, (__SingleBase), 10, Single);\
})

#define RegAddDouble2(arg1, arg2) \
    __RegAddDouble2_WB(__SINGLE_LIBBASE, (arg1), (arg2))

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)

#define __RegAdd3Quad1_WB(__SingleBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(SingleBase,1)\
        AROS_LC3QUAD1(LONG, RegAdd3Quad1,\
         AROS_LCA(LONG, (__arg1), D0), \
         AROS_LCA(LONG, (__arg2), D1), \
         AROS_LCA(LONG, (__arg3), D2), \
         AROS_LCA2(QUAD, (__arg4), D3, D4), \
        struct Library *, (__SingleBase), 11, Single);\
})

#define RegAdd3Quad1(arg1, arg2, arg3, arg4) \
    __RegAdd3Quad1_WB(__SINGLE_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

__END_DECLS

#endif /* DEFINES_SINGLE_H*/
