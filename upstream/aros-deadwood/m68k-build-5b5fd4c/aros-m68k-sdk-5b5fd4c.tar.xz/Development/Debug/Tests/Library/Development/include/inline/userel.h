#ifndef INLINE_USEREL_H
#define INLINE_USEREL_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/userel.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Inline function(s) for userel
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__USEREL_LIBBASE)
#define __USEREL_LIBBASE __aros_getbase_UseRelBase()
#endif
#ifndef __aros_getbase_UseRelBase
extern struct Library *__aros_getbase_UseRelBase(void);
#endif


#if !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__)

static inline LONG __inline_UseRel_UseRelAdd2(LONG __arg1, LONG __arg2, LONG __arg3, APTR __UseRelBase)
{
    AROS_LIBREQ(UseRelBase, 1)
    return AROS_LC3(LONG, UseRelAdd2,\
         AROS_LCA(LONG, (__arg1), D0), \
         AROS_LCA(LONG, (__arg2), D1), \
         AROS_LCA(LONG, (__arg3), D2), \
        struct Library *, (__UseRelBase), 5, UseRel    );
}

#define UseRelAdd2(arg1, arg2, arg3) \
    __inline_UseRel_UseRelAdd2((arg1), (arg2), (arg3), __USEREL_LIBBASE)

#endif /* !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__) */

#endif /* INLINE_USEREL_H*/
