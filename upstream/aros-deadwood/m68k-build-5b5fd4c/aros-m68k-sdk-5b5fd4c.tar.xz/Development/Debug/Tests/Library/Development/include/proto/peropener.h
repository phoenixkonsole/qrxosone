#ifndef PROTO_PEROPENER_H
#define PROTO_PEROPENER_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/peropener.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/peropener_protos.h>

#ifndef __PEROPENER_RELLIBBASE__
 #if !defined(__NOLIBBASE__) && !defined(__PEROPENER_NOLIBBASE__)
  #if !defined(PeropenerBase)
   extern struct Library *PeropenerBase;
  #endif
 #endif
 #ifndef __PEROPENER_LIBBASE
  #define __PEROPENER_LIBBASE (PeropenerBase)
 #endif
#else /* __PEROPENER_RELLIBASE__ */
 extern const IPTR __aros_rellib_offset_PeropenerBase;
 #define AROS_RELLIB_OFFSET_PEROPENER __aros_rellib_offset_PeropenerBase
 #define AROS_RELLIB_BASE_PEROPENER __aros_rellib_base_PeropenerBase
 #ifndef __PEROPENER_LIBBASE
  #ifndef __aros_getoffsettable
   char *__aros_getoffsettable(void);
  #endif
  #define __PEROPENER_LIBBASE (*(struct Library **)(__aros_getoffsettable()+__aros_rellib_offset_PeropenerBase))
 #endif
#endif
#ifndef __aros_getbase_PeropenerBase
extern struct Library *__aros_getbase_PeropenerBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(PEROPENER_NOLIBINLINE) && !defined(__PEROPENER_RELLIBBASE__)
# include <inline/peropener.h>
#elif !defined(NOLIBDEFINES) && !defined(PEROPENER_NOLIBDEFINES)
# include <defines/peropener.h>
#endif

#endif /* PROTO_PEROPENER_H */
