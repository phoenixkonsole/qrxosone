#ifndef DEFINES_PEROPENER_H
#define DEFINES_PEROPENER_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/peropener.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Defines for peropener
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__PEROPENER_LIBBASE)
#define __PEROPENER_LIBBASE __aros_getbase_PeropenerBase()
#endif
#ifndef __aros_getbase_PeropenerBase
extern struct Library *__aros_getbase_PeropenerBase(void);
#endif

__BEGIN_DECLS


#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)

#define __PeropenerSetValueReg_WB(__PeropenerBase, __arg1) ({\
        AROS_LIBREQ(PeropenerBase,4)\
        AROS_LC1NR(void, PeropenerSetValueReg,\
         AROS_LCA(int, (__arg1), D0), \
        struct Library *, (__PeropenerBase), 7, Peropener);\
})

#define PeropenerSetValueReg(arg1) \
    __PeropenerSetValueReg_WB(__PEROPENER_LIBBASE, (arg1))

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)

#define __PeropenerGetValueReg_WB(__PeropenerBase) ({\
        AROS_LIBREQ(PeropenerBase,4)\
        AROS_LC0(int, PeropenerGetValueReg,\
        struct Library *, (__PeropenerBase), 8, Peropener);\
})

#define PeropenerGetValueReg() \
    __PeropenerGetValueReg_WB(__PEROPENER_LIBBASE)

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)

#define __PeropenerSetGlobalPeropenerValueReg_WB(__PeropenerBase, __arg1) ({\
        AROS_LIBREQ(PeropenerBase,4)\
        AROS_LC1NR(void, PeropenerSetGlobalPeropenerValueReg,\
         AROS_LCA(int, (__arg1), D0), \
        struct Library *, (__PeropenerBase), 11, Peropener);\
})

#define PeropenerSetGlobalPeropenerValueReg(arg1) \
    __PeropenerSetGlobalPeropenerValueReg_WB(__PEROPENER_LIBBASE, (arg1))

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)

#define __PeropenerGetGlobalPeropenerValueReg_WB(__PeropenerBase) ({\
        AROS_LIBREQ(PeropenerBase,4)\
        AROS_LC0(int, PeropenerGetGlobalPeropenerValueReg,\
        struct Library *, (__PeropenerBase), 12, Peropener);\
})

#define PeropenerGetGlobalPeropenerValueReg() \
    __PeropenerGetGlobalPeropenerValueReg_WB(__PEROPENER_LIBBASE)

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

__END_DECLS

#endif /* DEFINES_PEROPENER_H*/
