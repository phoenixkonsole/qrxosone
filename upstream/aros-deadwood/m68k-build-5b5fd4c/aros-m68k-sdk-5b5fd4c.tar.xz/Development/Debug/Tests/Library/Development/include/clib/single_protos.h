#ifndef CLIB_SINGLE_PROTOS_H
#define CLIB_SINGLE_PROTOS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/single.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>


__BEGIN_DECLS


#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LP1(void, RegSetValue,
         AROS_LPA(LONG, v, D0),
         LIBBASETYPEPTR, SingleBase, 5, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LP4(LONG, RegAdd4,
         AROS_LPA(LONG, a1, D0),
         AROS_LPA(LONG, a2, D1),
         AROS_LPA(LONG, a3, D2),
         AROS_LPA(LONG, a4, D3),
         LIBBASETYPEPTR, SingleBase, 6, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LP6(LONG, RegAdd6,
         AROS_LPA(LONG, a1, D0),
         AROS_LPA(LONG, a2, D1),
         AROS_LPA(LONG, a3, D2),
         AROS_LPA(LONG, a4, D3),
         AROS_LPA(LONG, a5, D4),
         AROS_LPA(LONG, a6, D5),
         LIBBASETYPEPTR, SingleBase, 7, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LP9(LONG, RegAdd9,
         AROS_LPA(LONG, a1, D0),
         AROS_LPA(LONG, a2, D1),
         AROS_LPA(LONG, a3, D2),
         AROS_LPA(LONG, a4, D3),
         AROS_LPA(LONG, a5, D4),
         AROS_LPA(LONG, a6, D5),
         AROS_LPA(LONG, a7, D6),
         AROS_LPA(LONG, a8, D7),
         AROS_LPA(LONG, a9, A0),
         LIBBASETYPEPTR, SingleBase, 8, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LP0(double, RegReturnMinusPi,
         LIBBASETYPEPTR, SingleBase, 9, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LPDOUBLE2(double, RegAddDouble2,
         AROS_LPA2(double, a1, D0, D1),
         AROS_LPA2(double, a2, D2, D3),
         LIBBASETYPEPTR, SingleBase, 10, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
AROS_LP4(LONG, RegAdd3Quad1,
         AROS_LPA(LONG, a1, D0),
         AROS_LPA(LONG, a2, D1),
         AROS_LPA(LONG, a3, D2),
         AROS_LPA(QUAD, a4, D3/D4),
         LIBBASETYPEPTR, SingleBase, 11, Single
);

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
#ifndef StackSetValue
void StackSetValue(int v);
#endif

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
#ifndef StackAdd4
int StackAdd4(int a1, int a2, int a3, int a4);
#endif

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
#ifndef StackAdd6
int StackAdd6(int a1, int a2, int a3, int a4, int a5, int a6);
#endif

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
#ifndef StackAdd9
int StackAdd9(int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9);
#endif

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
#ifndef StackAdd4OrMore
int StackAdd4OrMore(int total, int a1, int a2, int a3, int a4, ...);
#endif

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

#if !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__)
#ifndef StackAddDouble2
double StackAddDouble2(double a1, double a2);
#endif

#endif /* !defined(__SINGLE_LIBAPI__) || (1 <= __SINGLE_LIBAPI__) */

__END_DECLS

#endif /* CLIB_SINGLE_PROTOS_H */
