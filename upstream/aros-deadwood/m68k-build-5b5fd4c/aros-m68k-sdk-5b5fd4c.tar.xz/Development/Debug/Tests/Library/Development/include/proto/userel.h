#ifndef PROTO_USEREL_H
#define PROTO_USEREL_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/userel.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/userel_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__USEREL_NOLIBBASE__)
  #if !defined(UseRelBase)
   extern struct Library *UseRelBase;
  #endif
 #endif
 #ifndef __USEREL_LIBBASE
  #define __USEREL_LIBBASE (UseRelBase)
 #endif
#ifndef __aros_getbase_UseRelBase
extern struct Library *__aros_getbase_UseRelBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(USEREL_NOLIBINLINE)
# include <inline/userel.h>
#elif !defined(NOLIBDEFINES) && !defined(USEREL_NOLIBDEFINES)
# include <defines/userel.h>
#endif

#endif /* PROTO_USEREL_H */
