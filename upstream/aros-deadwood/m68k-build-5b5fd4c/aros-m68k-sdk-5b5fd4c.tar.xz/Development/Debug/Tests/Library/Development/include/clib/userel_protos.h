#ifndef CLIB_USEREL_PROTOS_H
#define CLIB_USEREL_PROTOS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/userel.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>


__BEGIN_DECLS


#if !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__)
AROS_LP3(LONG, UseRelAdd2,
         AROS_LPA(LONG, base, D0),
         AROS_LPA(LONG, a, D1),
         AROS_LPA(LONG, b, D2),
         LIBBASETYPEPTR, UseRelBase, 5, UseRel
);

#endif /* !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__) */

#if !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__)
#ifndef UseRelAdd5
LONG UseRelAdd5(LONG base, LONG a, LONG b, LONG c, LONG d, LONG e);
#endif

#endif /* !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__) */

#if !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__)
#ifndef SetPeropenerLibraryValue
void SetPeropenerLibraryValue(int v);
#endif

#endif /* !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__) */

#if !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__)
#ifndef GetPeropenerLibraryValue
int GetPeropenerLibraryValue();
#endif

#endif /* !defined(__USEREL_LIBAPI__) || (1 <= __USEREL_LIBAPI__) */

__END_DECLS

#endif /* CLIB_USEREL_PROTOS_H */
