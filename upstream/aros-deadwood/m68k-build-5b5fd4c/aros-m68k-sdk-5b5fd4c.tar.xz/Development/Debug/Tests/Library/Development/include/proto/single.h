#ifndef PROTO_SINGLE_H
#define PROTO_SINGLE_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/single.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/single_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__SINGLE_NOLIBBASE__)
  #if !defined(SingleBase)
   extern struct Library *SingleBase;
  #endif
 #endif
 #ifndef __SINGLE_LIBBASE
  #define __SINGLE_LIBBASE (SingleBase)
 #endif
#ifndef __aros_getbase_SingleBase
extern struct Library *__aros_getbase_SingleBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(SINGLE_NOLIBINLINE)
# include <inline/single.h>
#elif !defined(NOLIBDEFINES) && !defined(SINGLE_NOLIBDEFINES)
# include <defines/single.h>
#endif

#endif /* PROTO_SINGLE_H */
