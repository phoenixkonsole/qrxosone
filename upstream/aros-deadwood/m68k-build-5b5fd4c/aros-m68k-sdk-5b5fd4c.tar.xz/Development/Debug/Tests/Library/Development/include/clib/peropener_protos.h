#ifndef CLIB_PEROPENER_PROTOS_H
#define CLIB_PEROPENER_PROTOS_H

/*
    *** Automatically generated from '/opt/qrx-os-one/deadwood-aros-build/AROS/developer/debug/test/library/peropener.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>

#include <exec/libraries.h>

__BEGIN_DECLS


#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef PeropenerSetValueStack
void PeropenerSetValueStack(int v);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef PeropenerGetValueStack
int PeropenerGetValueStack(void);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
AROS_LP1(void, PeropenerSetValueReg,
         AROS_LPA(int, v, D0),
         LIBBASETYPEPTR, PeropenerBase, 7, Peropener
);

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
AROS_LP0(int, PeropenerGetValueReg,
         LIBBASETYPEPTR, PeropenerBase, 8, Peropener
);

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef PeropenerNoLib
int PeropenerNoLib(void);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef PeropenerNameChange
int PeropenerNameChange(void);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
AROS_LP1(void, PeropenerSetGlobalPeropenerValueReg,
         AROS_LPA(int, v, D0),
         LIBBASETYPEPTR, PeropenerBase, 11, Peropener
);

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
AROS_LP0(int, PeropenerGetGlobalPeropenerValueReg,
         LIBBASETYPEPTR, PeropenerBase, 12, Peropener
);

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef Peropener_AllowShareable
void Peropener_AllowShareable(struct Library *base);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef Peropener_GetShareable
struct Library * Peropener_GetShareable(struct Library *base);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef Peropener_DisallowShareable
void Peropener_DisallowShareable(struct Library *base);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

#if !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__)
#ifndef PeropenerSetValueStackThroughInternalReg
void PeropenerSetValueStackThroughInternalReg(int v);
#endif

#endif /* !defined(__PEROPENER_LIBAPI__) || (4 <= __PEROPENER_LIBAPI__) */

__END_DECLS

#endif /* CLIB_PEROPENER_PROTOS_H */
