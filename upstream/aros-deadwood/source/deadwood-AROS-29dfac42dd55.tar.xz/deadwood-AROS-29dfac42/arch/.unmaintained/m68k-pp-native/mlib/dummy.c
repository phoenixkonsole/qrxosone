void dummy(void)
{
}
